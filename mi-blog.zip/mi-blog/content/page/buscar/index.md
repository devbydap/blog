---
title: "Buscar"
slug: "buscar"
layout: "search"
outputs:
    - html
    - json
menu:
    main:
        weight: 3
        params: 
            icon: search
---