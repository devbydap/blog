---
title: Bienvenido a devbydap
description: Aquí comparto lo que aprendo; desde cómo montar servidores, hasta cómo protegerlos.
slug: hello-world
date: 2025-10-20 00:00:00+0000
image: cover.png
categories:
tags:
weight: 1
---

Welcome to Hugo theme Stack. This is your first post. Edit or delete it, then start writing!

For more information about this theme, check the documentation: https://stack.jimmycai.com/

Want a site like this? Check out [hugo-theme-stack-stater](https://github.com/TuNombre/hugo-theme-stack-starter)

> Photo by [Pawel Czerwinski](https://unsplash.com/@pawel_czerwinski) on [Unsplash](https://unsplash.com/)